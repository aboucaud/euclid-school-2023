"""cosmo_1_galaxy dataset."""

import tensorflow_datasets as tfds
import tensorflow as tf
import numpy as np

class Builder(tfds.core.GeneratorBasedBuilder):
  """DatasetBuilder for cosmo_1_galaxy dataset."""

  MANUAL_DOWNLOAD_INSTRUCTIONS = """
  Register into https://example.org/login to get the data. Place the `data.zip`
  file in the `manual_dir/`.
  """  

  VERSION = tfds.core.Version('1.0.1')
  RELEASE_NOTES = {
      '1.0.1': 'SIMBA cosmosim',
  }

  def _info(self) -> tfds.core.DatasetInfo:
    """Returns the dataset metadata."""
    # TODO(cosmo_1_galaxy): Specifies the tfds.core.DatasetInfo object
    return self.dataset_info_from_configs(
        features=tfds.features.FeaturesDict({
            # These are the features of your dataset like images, labels ...
            'input': tfds.features.Tensor(shape=(17,), dtype=tf.float32),
            'output': tfds.features.Tensor(shape=(6,), dtype=tf.float32),
        }),
        # If there's a common (input, target) tuple from the
        # features, specify them here. They'll be used if
        # `as_supervised=True` in `builder.as_dataset`.
        supervised_keys=('input', 'output'),  # Set to `None` to disable
        homepage='https://dataset-homepage/',
    )

  def _split_generators(self, dl_manager):
    """Returns SplitGenerators."""
    
    # TODO(cosmo_1_galaxy): Downloads the data and defines the splits
    # data parameters
    root        =  dl_manager.manual_dir ##'/home/jovyan/home'
    sim         = 'SIMBA'
    f_prop      = '%s/galaxies_%s_z=0.00.txt'%(root,sim)
    f_prop_norm = None
    f_off       = '%s/offset_%s_z=0.00.txt'%(root,sim)
    f_params    = '%s/latin_hypercube_params_%s.txt'%(root,sim)
    seed        = 1
    num_workers = 8
    prefix      = 'all-Vmax-Vdisp-Mtot-Rtot-Rmax_Om_s8_A1_A2_A3_A4_z=0.0'
    features    = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16] #features used as input
    #prefix      = 'Mstar_Vdisp_Zs_Rstar_K'
    #prefix      = 'Mgas_Mstar_Vmax_Zg_K_z=0'

    # TODO(cosmo_1_galaxy): Returns the Dict[split names, Iterator[Key, Example]]
    return {
        'train': self._generate_examples("train",seed, f_prop, f_off, f_prop_norm, f_params, features),
        'valid': self._generate_examples("valid",seed, f_prop, f_off, f_prop_norm, f_params, features),
        'test': self._generate_examples("test",seed, f_prop, f_off, f_prop_norm, f_params, features),
    }

  def _generate_examples(self, mode, seed, f_prop, f_off, f_prop_norm, f_params, features):
    """Yields examples."""
    # read data, scale it, and normalize it
    data = np.loadtxt(f_prop)
    data = data[:,features]
    data[np.where(data==0.0)] += 1e-30
    indexes = np.where(data>0.0)
    data[indexes] = np.log10(data[indexes])
    if f_prop_norm is None:
        mean, std = np.mean(data, axis=0), np.std(data, axis=0)
    else:
        data_norm = np.loadtxt(f_prop_norm)
        data_norm = data_norm[:,features]
        data_norm[np.where(data_norm==0.0)] += 1e-30
        indexes = np.where(data_norm>0.0)
        data_norm[indexes] = np.log10(data_norm[indexes])
        mean, std = np.mean(data_norm, axis=0), np.std(data_norm, axis=0)
    data = (data - mean)/std
    off, length = np.loadtxt(f_off, dtype=np.int64, unpack=True)
        
    # read the value of the cosmological & astrophysical parameters; normalize them
    params  = np.loadtxt(f_params)
    minimum = np.array([0.1, 0.6, 0.25, 0.25, 0.5, 0.5])
    maximum = np.array([0.5, 1.0, 4.00, 4.00, 2.0, 2.0])
    params  = (params - minimum)/(maximum - minimum)

    # get the size and offset depending on the type of dataset
    sims = params.shape[0]
    if   mode=='train':  size, offset = int(sims*0.85), int(sims*0.00)
    elif mode=='valid':  size, offset = int(sims*0.10), int(sims*0.85)
    elif mode=='test':   size, offset = int(sims*0.05), int(sims*0.95)
    elif mode=='all':    size, offset = int(sims*1.00), int(sims*0.00)
    else:                raise Exception('Wrong name!')    
        
    # randomly shuffle the sims. Instead of 0 1 2 3...999 have a 
    # random permutation. E.g. 5 9 0 29...342
    np.random.seed(seed)
    indexes = np.arange(sims) #shuffle the order of the simulations
    np.random.shuffle(indexes)
    indexes = indexes[offset:offset+size] #select indexes of mode

    # get the indexes of the galaxies in the considered set
    Ngal = 0
    for i in indexes:
        Ngal += length[i]
    print('Number of galaxies in the %s set: %d'%(mode,Ngal))  
    
    
    # define the arrays containing the properties and the parameter values
    prop = np.zeros((Ngal, data.shape[1]),   dtype=np.float32)
    pars = np.zeros((Ngal, params.shape[1]), dtype=np.float32)

    # fill the arrays
    num_features = len(features)
    count = 0
    for i in indexes:
        for j in range(length[i]):
            prop[count, :num_features] = data[off[i] + j]
            #prop[count, num_features:] = params[i,[2,3,4,5]]
            pars[count] = params[i]
            count += 1
            yield count, {
          'input': prop[count-1],
          'output': pars[count-1],
      }
    print('processed %d galaxies'%count)

  
  
