"""multifield dataset."""

import tensorflow_datasets as tfds
import tensorflow as tf
import numpy as np



class Builder(tfds.core.GeneratorBasedBuilder):
  """DatasetBuilder for multifield dataset."""

  VERSION = tfds.core.Version('1.0.0')
  RELEASE_NOTES = {
      '1.0.0': 'Initial release.',
  }

  
    
  #MAPS = ['Mgas','Vgas','T','P','Z','HI','ne','B','MgFe','Mcdm','Vcdm','Mstar','Mtot']  

  def construct_features(self,maps):
    features_dict = {
        'cosmo': tfds.features.Tensor(shape=(6,), dtype=tf.float32),
    }
    
    for map_name in maps:
        features_dict[map_name] = tfds.features.Tensor(shape=(256, 256, 1), dtype=tf.float32)
        
    return features_dict  

  def _info(self) -> tfds.core.DatasetInfo:
    """Returns the dataset metadata."""
    # TODO(multifield): Specifies the tfds.core.DatasetInfo object
    MAPS = ['Mgas','Mstar','Vcdm','Z']
    #MAPS = ['Mgas','Vgas','T','P','Z','HI','ne','B','MgFe','Mcdm','Vcdm','Mstar','Mtot']
    features=self.construct_features(MAPS)
    return self.dataset_info_from_configs(
        features=tfds.features.FeaturesDict(features),
        # If there's a common (input, target) tuple from the
        # features, specify them here. They'll be used if
        # `as_supervised=True` in `builder.as_dataset`.
        supervised_keys=('Mgas', 'cosmo'),  # Set to `None` to disable
        homepage='https://camels-multifield-dataset.readthedocs.io/en/latest/data.html#d-maps',
    )

  def _split_generators(self, dl_manager: tfds.download.DownloadManager):
    """Returns SplitGenerators."""
    # TODO(multifield): Downloads the data and defines the splits
    path = '/home/jovyan/Data/CMD/2D_maps/data'
    #path = dl_manager.manual_dir
    
    root        =  '/home/jovyan/Data/CMD/2D_maps/data/'
    sim         = 'IllustrisTNG'
    #maps = ['Mgas','Vgas','T','P','Z','HI','ne','B','MgFe','Mcdm','Vcdm','Mstar','Mtot']
    maps = ['Mgas','Mstar','Vcdm','Z']
    fparams = "params_LH_"+sim+".txt"
    seed        = 1
    
    #path = dl_manager.download_and_extract('https://todo-data-url')

    # TODO(multifield): Returns the Dict[split names, Iterator[Key, Example]]
    return {
        'train': self._generate_examples("train",seed, root, sim, maps,fparams),
        'valid': self._generate_examples("valid",seed, root, sim, maps,fparams),
        'test': self._generate_examples("test",seed, root, sim, maps,fparams)
    }

  def _generate_examples(self, mode, seed, root, sim, maps,fparams):
    """Yields examples."""
    # TODO(multifield): Yields (key, example) tuples from the dataset
    image_dict = {}
    for f in maps:
        mname = root+"Maps_"+f+"_"+sim+"_LH_z=0.00.npy"
        images = np.load(mname)
        print('loaded'+f)
        image_dict[f] = images
    
    num_tot = len(image_dict[maps[0]])
    if   mode=='train':  num_images = int(num_tot*0.85)
    elif mode=='valid':  num_images = int(num_tot*0.10)
    elif mode=='test':   num_images = int(num_tot*0.05)
    elif mode=='all':    num_images = int(num_tot*1.00)
    else:                raise Exception('Wrong name!') 
    
    
    params  = np.loadtxt(root+fparams)
    
    
    for ind in range(num_images):
        #data = {'ind': ind}
        data={}
        for map_name in maps:
            data[map_name] = np.expand_dims(image_dict[map_name][ind],2)
            
        data['cosmo'] = (params[ind//15]).astype(np.float32)    

        yield ind,data    
        
   # for ind,mgas_image, vgas_image, T_image, P_image, Z_image, HI_image, ne_image, B_image, MgFe_image, Mcdm_image, Vcdm_image, Mstar_image, Mtot_image in zip(range(len(images)),image_dict['Mgas'], image_dict['Vgas'],image_dict['T'],image_dict['P'],image_dict['Z'],image_dict['HI'],image_dict['ne'],image_dict['B'],image_dict['MgFe'],image_dict['Mcdm'],image_dict['Vcdm'],image_dict['Mstar'],image_dict['Mtot']):
    #    yield ind, {
     #       'Mgas': mgas_image,
      #      'Vgas': vgas_image,
       #     'T': T_image,
        #    'P': P_image,
         #   'Z': Z_image,
        #    'HI': HI_image,
         #   'ne': ne_image,
         #   'B': B_image,
         #   'MgFe': MgFe_image,
         #   'Mcdm': Mcdm_image,
         #   'Vcdm': Vcdm_image,
         #   'Mstar': Mstar_image,
         #   'Mtot': Mtot_image,
            
           
            
       # }
    
    
    
