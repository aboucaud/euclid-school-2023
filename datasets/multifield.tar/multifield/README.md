TODO(multifield): Markdown description of that will appear on the catalog page.
Description is **formatted** as markdown.

It should also contain any processing which has been applied (if any),
(e.g. corrupted example skipped, images cropped,...):
